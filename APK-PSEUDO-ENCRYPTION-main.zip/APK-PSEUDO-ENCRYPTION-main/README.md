# APK Pseudo-Encryption

A minimal Python tool (with Tkinter GUI) that applies **XOR-based pseudo-encryption** to an APK file.

⚠️  This is *not* real encryption.  It merely obfuscates the APK by XOR-ing its bytes with a user-supplied key and is easily reversible.  Use only as a trivial deterrent or educational demo.

## Requirements

* Python ≥ 3.8 (Tkinter ships with the standard installer)

No external packages are required.

## Usage

### GUI

```bash
python gui.py
```

1. Click **Browse…** to choose an `.apk` file.
2. Enter an arbitrary key (any text).  The same key must be used to decrypt.
3. Press **Encrypt** or **Decrypt**.

The tool writes a new file next to the original:

* `MyApp.apk` → `MyApp.apk.enc.apk` (encrypted)
* `MyApp.apk.enc.apk` → `MyApp.apk.enc.apk.dec.apk` (decrypted)

### CLI (script)

If you prefer to call the logic directly:

```python
from encryption import encrypt_file, decrypt_file

encrypt_file("MyApp.apk", "MyApp.apk.xor.apk", key="secret")
```

## License

MIT
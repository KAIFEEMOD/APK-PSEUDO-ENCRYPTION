"""Tkinter-based GUI wrapper around the `encryption` module.

Run `python gui.py` to start the application.
"""
from __future__ import annotations

import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox

import encryption


class App(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("APK Pseudo-Encryption")
        self.geometry("460x200")
        self.resizable(False, False)

        # Selected file path (string-var so widgets auto-update)
        self.file_var = tk.StringVar()
        # Key entry text-variable
        self.key_var = tk.StringVar()

        self._build_ui()

    # ------------------------------------------------------------------
    # UI construction helpers
    # ------------------------------------------------------------------
    def _build_ui(self) -> None:
        padding = {"padx": 10, "pady": 10}

        # File chooser row
        file_frame = tk.Frame(self)
        file_frame.pack(fill="x", **padding)

        tk.Label(file_frame, text="APK file:").pack(side="left")
        tk.Entry(file_frame, textvariable=self.file_var, width=40).pack(side="left", expand=True, fill="x", padx=(5, 5))
        tk.Button(file_frame, text="Browse…", command=self._choose_file).pack(side="left")

        # Key row
        key_frame = tk.Frame(self)
        key_frame.pack(fill="x", **padding)

        tk.Label(key_frame, text="Key:").pack(side="left")
        tk.Entry(key_frame, textvariable=self.key_var, width=25, show="*").pack(side="left", expand=True, fill="x", padx=(5, 5))

        # Action buttons
        btn_frame = tk.Frame(self)
        btn_frame.pack(fill="x", **padding)

        tk.Button(btn_frame, text="Encrypt", command=self._encrypt).pack(side="left", expand=True, fill="x", padx=(0, 5))
        tk.Button(btn_frame, text="Decrypt", command=self._decrypt).pack(side="left", expand=True, fill="x", padx=(5, 0))

    # ------------------------------------------------------------------
    # Button callbacks
    # ------------------------------------------------------------------
    def _choose_file(self) -> None:
        path = filedialog.askopenfilename(filetypes=[("APK files", "*.apk"), ("All files", "*.*")])
        if path:
            self.file_var.set(path)

    def _encrypt(self) -> None:
        self._process(encrypt=True)

    def _decrypt(self) -> None:
        self._process(encrypt=False)

    # ------------------------------------------------------------------
    # Core processing helper
    # ------------------------------------------------------------------
    def _process(self, *, encrypt: bool) -> None:
        src_path = Path(self.file_var.get())
        key = self.key_var.get()

        if not src_path.is_file():
            messagebox.showerror("Error", "Please select a valid APK file.")
            return
        if not key:
            messagebox.showerror("Error", "Please enter a key.")
            return

        # Determine output file name
        suffix = ".enc.apk" if encrypt else ".dec.apk"
        dst_path = src_path.with_suffix(src_path.suffix + suffix)  # e.g. MyApp.apk -> MyApp.apk.enc.apk

        try:
            if encrypt:
                encryption.encrypt_file(src_path, dst_path, key)
            else:
                encryption.decrypt_file(src_path, dst_path, key)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Error", str(exc))
            return

        messagebox.showinfo("Success", f"Output written to: {dst_path}")


if __name__ == "__main__":
    App().mainloop()

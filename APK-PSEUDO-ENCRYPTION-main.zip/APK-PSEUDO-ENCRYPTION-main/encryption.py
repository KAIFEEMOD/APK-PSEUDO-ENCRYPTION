"""Simple XOR-based pseudo encryption utilities for APK files.

This module provides two high-level helpers, `encrypt_file` and `decrypt_file`,
which work on any file – APKs are just ZIP archives, so processing them as raw
bytes is sufficient for simple obfuscation.

This is *not* real encryption. It is a reversible XOR transformation intended
only as a demonstration or very light-weight deterrent. Do not rely on this for
serious security needs.
"""
from __future__ import annotations

__all__ = [
    "encrypt_file",
    "decrypt_file",
]

from pathlib import Path

# ---------------------------------------------------------------------------
# Low-level helpers
# ---------------------------------------------------------------------------

def _xor_bytes(data: bytes, key: bytes) -> bytes:
    """Return *data* XOR-ed with *key* (cycled).

    Parameters
    ----------
    data:
        Input byte sequence.
    key:
        Key as bytes. Empty key raises ``ValueError``.
    """
    if not key:
        raise ValueError("Key must not be empty")

    key_len = len(key)
    return bytes(byte ^ key[i % key_len] for i, byte in enumerate(data))


# ---------------------------------------------------------------------------
# Public helpers
# ---------------------------------------------------------------------------

def encrypt_file(input_path: str | Path, output_path: str | Path, key: str) -> None:
    """Encrypt *input_path* -> *output_path* using *key*.

    A new file at *output_path* is always written. An existing file will be
    silently overwritten.
    """
    _transform_file(input_path, output_path, key)


def decrypt_file(input_path: str | Path, output_path: str | Path, key: str) -> None:
    """Decrypt *input_path* -> *output_path* using *key*.

    Because XOR is symmetric, decryption is identical to encryption.
    """
    _transform_file(input_path, output_path, key)


# ---------------------------------------------------------------------------
# Internal implementation
# ---------------------------------------------------------------------------

def _transform_file(input_path: str | Path, output_path: str | Path, key: str) -> None:
    input_path = Path(input_path)
    output_path = Path(output_path)

    key_bytes = key.encode("utf-8")
    if not key_bytes:
        raise ValueError("Key must not be empty")

    data = input_path.read_bytes()
    transformed = _xor_bytes(data, key_bytes)

    output_path.write_bytes(transformed)
